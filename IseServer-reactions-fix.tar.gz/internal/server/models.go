package server

type messageReactionJSON struct {
	Emoji string `json:"emoji"`
	Count int    `json:"count"`
	Mine  bool   `json:"mine,omitempty"`
}

type messageJSON struct {
	ID              int64                  `json:"id"`
	ChatID          int64                  `json:"chat_id"`
	SenderID        int64                  `json:"sender_id"`
	SenderName      string                 `json:"sender_name"`
	Text            string                 `json:"text"`
	CreatedAt       string                 `json:"created_at"`
	Mine            bool                   `json:"mine,omitempty"`
	Read            bool                   `json:"read"`
	Kind            string                 `json:"kind"`
	MediaURL        string                 `json:"media_url,omitempty"`
	MediaMime       string                 `json:"media_mime,omitempty"`
	MediaName       string                 `json:"media_name,omitempty"`
	MediaSize       int64                  `json:"media_size,omitempty"`
	MediaWidth      int                    `json:"media_width,omitempty"`
	MediaHeight     int                    `json:"media_height,omitempty"`
	MediaDuration   int64                  `json:"media_duration,omitempty"`
	MediaGroupID    string                 `json:"media_group_id,omitempty"`
	ReplyToID       int64                  `json:"reply_to_id,omitempty"`
	ReplySender     string                 `json:"reply_sender_name,omitempty"`
	ReplyText       string                 `json:"reply_text,omitempty"`
	ReplyKind       string                 `json:"reply_kind,omitempty"`
	ForwardedFrom   string                 `json:"forwarded_from_name,omitempty"`
	ForwardedFromID int64                  `json:"forwarded_from_id,omitempty"`
	Edited          bool                   `json:"edited"`
	Reactions       *[]messageReactionJSON `json:"reactions,omitempty"`
}

type chatJSON struct {
	ID                 int64  `json:"id"`
	UserID             int64  `json:"user_id"`
	Name               string `json:"name"`
	DefaultName        string `json:"default_name"`
	CustomName         string `json:"custom_name"`
	Email              string `json:"email"`
	LastMessage        string `json:"last_message"`
	LastKind           string `json:"last_kind"`
	LastID             int64  `json:"last_message_id"`
	UpdatedAt          string `json:"updated_at"`
	Unread             int    `json:"unread"`
	LastMine           bool   `json:"last_mine"`
	LastRead           bool   `json:"last_read"`
	Online             bool   `json:"online"`
	LastSeenAt         string `json:"last_seen_at"`
	Avatar             string `json:"avatar"`
	AvatarGradientSeed int64  `json:"avatar_gradient_seed"`
	Saved              bool   `json:"saved"`
	Group              bool   `json:"group"`
	Owner              bool   `json:"owner"`
	MemberCount        int    `json:"member_count"`
	Archived           bool   `json:"archived"`
}
