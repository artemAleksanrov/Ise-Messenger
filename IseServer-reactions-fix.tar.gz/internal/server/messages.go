package server

import (
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

func (s *server) listMessages(w http.ResponseWriter, r *http.Request, chatID, userID int64) {
	var otherLastRead int64
	var memberCount int
	if err := s.db.QueryRowContext(r.Context(), `SELECT COUNT(*), COALESCE(MIN(CASE WHEN user_id <> ? THEN last_read_message_id END), 0) FROM chat_members WHERE chat_id = ?`, userID, chatID).Scan(&memberCount, &otherLastRead); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось загрузить сообщения")
		return
	}
	after, _ := strconv.ParseInt(r.URL.Query().Get("after"), 10, 64)
	before, _ := strconv.ParseInt(r.URL.Query().Get("before"), 10, 64)
	query := `SELECT m.id, m.sender_id, COALESCE(u.name, ''), m.text, m.kind, COALESCE(m.media_mime, ''), COALESCE(m.media_name, ''), m.media_size, m.media_width, m.media_height, m.media_duration, m.media_group_id, m.reply_to_id, m.reply_sender_name, m.reply_text, m.reply_kind, m.forwarded_from_name, m.forwarded_from_id, m.edited_at IS NOT NULL, CAST(UNIX_TIMESTAMP(m.created_at) AS SIGNED) FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.chat_id = ? ORDER BY m.id DESC LIMIT 100`
	args := []any{chatID}
	ascending := false
	if after > 0 {
		query = `SELECT m.id, m.sender_id, COALESCE(u.name, ''), m.text, m.kind, COALESCE(m.media_mime, ''), COALESCE(m.media_name, ''), m.media_size, m.media_width, m.media_height, m.media_duration, m.media_group_id, m.reply_to_id, m.reply_sender_name, m.reply_text, m.reply_kind, m.forwarded_from_name, m.forwarded_from_id, m.edited_at IS NOT NULL, CAST(UNIX_TIMESTAMP(m.created_at) AS SIGNED) FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.chat_id = ? AND m.id > ? ORDER BY m.id ASC LIMIT 100`
		args = append(args, after)
		ascending = true
	} else if before > 0 {
		query = `SELECT m.id, m.sender_id, COALESCE(u.name, ''), m.text, m.kind, COALESCE(m.media_mime, ''), COALESCE(m.media_name, ''), m.media_size, m.media_width, m.media_height, m.media_duration, m.media_group_id, m.reply_to_id, m.reply_sender_name, m.reply_text, m.reply_kind, m.forwarded_from_name, m.forwarded_from_id, m.edited_at IS NOT NULL, CAST(UNIX_TIMESTAMP(m.created_at) AS SIGNED) FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.chat_id = ? AND m.id < ? ORDER BY m.id DESC LIMIT 100`
		args = append(args, before)
	}
	rows, err := s.db.QueryContext(r.Context(), query, args...)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось загрузить сообщения")
		return
	}
	defer rows.Close()
	messages := make([]messageJSON, 0, 100)
	var maxID int64
	for rows.Next() {
		var item messageJSON
		var createdUnix int64
		if err := rows.Scan(&item.ID, &item.SenderID, &item.SenderName, &item.Text, &item.Kind, &item.MediaMime, &item.MediaName, &item.MediaSize, &item.MediaWidth, &item.MediaHeight, &item.MediaDuration, &item.MediaGroupID, &item.ReplyToID, &item.ReplySender, &item.ReplyText, &item.ReplyKind, &item.ForwardedFrom, &item.ForwardedFromID, &item.Edited, &createdUnix); err != nil {
			writeError(w, http.StatusInternalServerError, "Не удалось загрузить сообщения")
			return
		}
		item.Text, err = s.decryptMessageText(item.Text)
		if err == nil {
			item.ReplyText, err = s.decryptMessageText(item.ReplyText)
		}
		if err != nil {
			writeError(w, http.StatusInternalServerError, "Не удалось расшифровать сообщения")
			return
		}
		item.ChatID = chatID
		item.Mine = item.SenderID == userID
		item.Read = item.Mine && (memberCount == 1 || item.ID <= otherLastRead)
		item.CreatedAt = timestampJSON(createdUnix)
		if item.Kind == "image" || item.Kind == "video" || item.Kind == "video_note" || item.Kind == "audio" || item.Kind == "file" {
			item.MediaURL = "/media/" + strconv.FormatInt(item.ID, 10)
		} else if item.Kind != "call" {
			item.Kind = "text"
		}
		if item.ID > maxID {
			maxID = item.ID
		}
		messages = append(messages, item)
	}
	if err := rows.Err(); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось загрузить сообщения")
		return
	}
	if !ascending {
		for left, right := 0, len(messages)-1; left < right; left, right = left+1, right-1 {
			messages[left], messages[right] = messages[right], messages[left]
		}
	}
	if err := s.loadMessageReactions(messages, userID); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось загрузить реакции")
		return
	}
	if maxID > 0 {
		_ = s.updateRead(chatID, userID, maxID)
	}
	writeJSON(w, http.StatusOK, map[string]any{"messages": messages})
}

func (s *server) createMessage(w http.ResponseWriter, r *http.Request, chatID, userID int64) {
	var body struct {
		Text      string `json:"text"`
		ReplyToID int64  `json:"reply_to_id"`
	}
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "Проверьте данные")
		return
	}
	text := strings.TrimSpace(body.Text)
	if text == "" || utf8.RuneCountInString(text) > 4000 {
		writeError(w, http.StatusBadRequest, "Сообщение должно содержать от 1 до 4000 символов")
		return
	}
	var replySender, replyText, replyKind string
	if body.ReplyToID > 0 {
		err := s.db.QueryRow(`SELECT COALESCE(u.name, ''), m.text, m.kind FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ? AND m.chat_id = ? AND m.kind <> 'call'`, body.ReplyToID, chatID).Scan(&replySender, &replyText, &replyKind)
		if errors.Is(err, sql.ErrNoRows) {
			writeError(w, http.StatusBadRequest, "Сообщение для ответа не найдено")
			return
		}
		if err != nil {
			writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
			return
		}
		replyText, err = s.decryptMessageText(replyText)
		if err != nil {
			writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
			return
		}
		replyText = truncateRunes(replyText, 512)
	}
	senderName, err := s.userName(userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
		return
	}
	encryptedText, err := s.encryptMessageText(text)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
		return
	}
	encryptedReply, err := s.encryptMessageText(replyText)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
		return
	}
	result, err := s.db.Exec(`INSERT INTO messages (chat_id, sender_id, text, reply_to_id, reply_sender_name, reply_text, reply_kind) SELECT ?, ?, ?, ?, ?, ?, ? FROM chat_members WHERE chat_id = ? AND user_id = ? LIMIT 1`, chatID, userID, encryptedText, body.ReplyToID, replySender, encryptedReply, replyKind, chatID, userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
		return
	}
	affected, err := result.RowsAffected()
	if err != nil || affected != 1 {
		writeError(w, http.StatusForbidden, "Нет доступа к чату")
		return
	}
	messageID, err := result.LastInsertId()
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отправить сообщение")
		return
	}
	createdUnix := time.Now().Unix()
	_ = s.updateRead(chatID, userID, messageID)
	item := messageJSON{ID: messageID, ChatID: chatID, SenderID: userID, SenderName: senderName, Text: text, CreatedAt: timestampJSON(createdUnix), Mine: true, Kind: "text", ReplyToID: body.ReplyToID, ReplySender: replySender, ReplyText: replyText, ReplyKind: replyKind}
	s.deliverMessage(item, userID)
	writeJSON(w, http.StatusCreated, map[string]any{"message": item})
}

func (s *server) deliverMessage(item messageJSON, userID int64) {
	event, _ := json.Marshal(map[string]any{"type": "message", "message": item})
	rows, err := s.db.Query(`SELECT user_id FROM chat_members WHERE chat_id = ?`, item.ChatID)
	if err == nil {
		recipients := make([]int64, 0, 4)
		pushRecipients := make([]int64, 0, 4)
		for rows.Next() {
			var id int64
			if rows.Scan(&id) == nil {
				recipients = append(recipients, id)
				if id != userID {
					pushRecipients = append(pushRecipients, id)
				}
			}
		}
		rowsErr := rows.Err()
		rows.Close()
		if rowsErr != nil {
			return
		}
		s.hub.broadcast(recipients, event)
		if len(pushRecipients) == 0 {
			return
		}
		body := item.Text
		if item.Kind == "image" {
			body = "Фото"
		} else if item.Kind == "video" {
			body = "Видео"
		} else if item.Kind == "video_note" {
			body = "Видеосообщение"
		} else if item.Kind == "audio" {
			if strings.HasPrefix(strings.ToLower(item.MediaName), "voice_") {
				body = "Голосовое сообщение"
			} else {
				body = "Аудио"
			}
		} else if item.Kind == "file" {
			body = "Файл: " + item.MediaName
		}
		title := item.SenderName
		var chatKind, groupName string
		if s.db.QueryRow(`SELECT kind, COALESCE(name, '') FROM chats WHERE id = ?`, item.ChatID).Scan(&chatKind, &groupName) == nil && chatKind == "group" {
			title = groupName
			body = item.SenderName + ": " + body
		}
		for _, recipientID := range pushRecipients {
			s.enqueueNotification(recipientID, title, truncateNotification(body), map[string]string{
				"type": "message", "chat_id": strconv.FormatInt(item.ChatID, 10), "message_id": strconv.FormatInt(item.ID, 10), "sender_id": strconv.FormatInt(item.SenderID, 10),
			})
		}
	}
}

func (s *server) handleMessageAction(w http.ResponseWriter, r *http.Request) {
	userID, ok := s.requireUser(w, r)
	if !ok {
		return
	}
	parts := strings.Split(strings.Trim(strings.TrimPrefix(r.URL.Path, "/messages/"), "/"), "/")
	messageID, err := strconv.ParseInt(parts[0], 10, 64)
	if err != nil || messageID < 1 {
		writeError(w, http.StatusBadRequest, "Некорректное сообщение")
		return
	}
	if len(parts) == 1 && r.Method == http.MethodDelete {
		s.deleteMessage(w, messageID, userID)
		return
	}
	if len(parts) == 1 && r.Method == http.MethodPatch {
		s.editMessage(w, r, messageID, userID)
		return
	}
	if len(parts) == 2 && parts[1] == "forward" && r.Method == http.MethodPost {
		s.forwardMessage(w, r, messageID, userID)
		return
	}
	if len(parts) == 2 && parts[1] == "reaction" && r.Method == http.MethodPost {
		s.setMessageReaction(w, r, messageID, userID)
		return
	}
	writeError(w, http.StatusMethodNotAllowed, "Метод не поддерживается")
}

func (s *server) setMessageReaction(w http.ResponseWriter, r *http.Request, messageID, userID int64) {
	var body struct {
		Emoji  string `json:"emoji"`
		Remove bool   `json:"remove"`
	}
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "Проверьте данные")
		return
	}
	emoji := strings.TrimSpace(body.Emoji)
	if body.Remove {
		emoji = ""
	}
	if emoji != "" && !validMessageReaction(emoji) {
		writeError(w, http.StatusBadRequest, "Недоступная реакция")
		return
	}

	tx, err := s.db.BeginTx(r.Context(), nil)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить реакцию")
		return
	}
	defer tx.Rollback()
	var chatID int64
	err = tx.QueryRowContext(r.Context(), `SELECT m.chat_id FROM messages m JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = ? WHERE m.id = ? AND m.kind <> 'call' FOR UPDATE`, userID, messageID).Scan(&chatID)
	if errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить реакцию")
		return
	}
	if emoji == "" {
		_, err = tx.ExecContext(r.Context(), `DELETE FROM message_reactions WHERE message_id = ? AND user_id = ?`, messageID, userID)
	} else {
		_, err = tx.ExecContext(r.Context(), `INSERT INTO message_reactions (message_id, user_id, emoji) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE emoji = VALUES(emoji), updated_at = CURRENT_TIMESTAMP(6)`, messageID, userID, emoji)
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить реакцию")
		return
	}
	if err = tx.Commit(); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить реакцию")
		return
	}

	reactions, err := s.messageReactionSummary(messageID, userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось загрузить реакции")
		return
	}
	publicReactions := make([]messageReactionJSON, len(reactions))
	for index, reaction := range reactions {
		publicReactions[index] = messageReactionJSON{Emoji: reaction.Emoji, Count: reaction.Count}
	}
	event, _ := json.Marshal(map[string]any{
		"type": "message_reactions", "chat_id": chatID, "message_id": messageID,
		"reactions": publicReactions, "reactor_id": userID, "emoji": emoji,
	})
	rows, queryErr := s.db.QueryContext(r.Context(), `SELECT user_id FROM chat_members WHERE chat_id = ?`, chatID)
	if queryErr == nil {
		recipients := make([]int64, 0, 4)
		for rows.Next() {
			var recipientID int64
			if rows.Scan(&recipientID) == nil {
				recipients = append(recipients, recipientID)
			}
		}
		rows.Close()
		s.hub.broadcast(recipients, event)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"message_id": messageID, "chat_id": chatID, "reactions": reactions, "my_reaction": emoji,
	})
}

func validMessageReaction(emoji string) bool {
	switch emoji {
	case "👍", "❤️", "😂", "😮", "😢",
		"🔥", "👏", "🎉", "😍", "🤔",
		"👎", "😡", "🤯", "😭", "🙏",
		"👌", "💯", "🤣", "😊", "😎",
		"🤩", "😴", "🤢", "💩", "🥳":
		return true
	default:
		return false
	}
}

func (s *server) loadMessageReactions(messages []messageJSON, userID int64) error {
	if len(messages) == 0 {
		return nil
	}
	messageIndexes := make(map[int64]int, len(messages))
	placeholders := make([]string, len(messages))
	args := make([]any, 0, len(messages)+1)
	args = append(args, userID)
	for index := range messages {
		messageIndexes[messages[index].ID] = index
		placeholders[index] = "?"
		args = append(args, messages[index].ID)
		empty := make([]messageReactionJSON, 0)
		messages[index].Reactions = &empty
	}
	query := `SELECT message_id, emoji, COUNT(*), MAX(user_id = ?) FROM message_reactions WHERE message_id IN (` + strings.Join(placeholders, ",") + `) GROUP BY message_id, emoji ORDER BY message_id`
	rows, err := s.db.Query(query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var messageID int64
		var reaction messageReactionJSON
		var mine int
		if err := rows.Scan(&messageID, &reaction.Emoji, &reaction.Count, &mine); err != nil {
			return err
		}
		reaction.Mine = mine > 0
		if index, ok := messageIndexes[messageID]; ok {
			*messages[index].Reactions = append(*messages[index].Reactions, reaction)
		}
	}
	return rows.Err()
}

func (s *server) messageReactionSummary(messageID, userID int64) ([]messageReactionJSON, error) {
	rows, err := s.db.Query(`SELECT emoji, COUNT(*), MAX(user_id = ?) FROM message_reactions WHERE message_id = ? GROUP BY emoji`, userID, messageID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	reactions := make([]messageReactionJSON, 0, 5)
	for rows.Next() {
		var reaction messageReactionJSON
		var mine int
		if err := rows.Scan(&reaction.Emoji, &reaction.Count, &mine); err != nil {
			return nil, err
		}
		reaction.Mine = mine > 0
		reactions = append(reactions, reaction)
	}
	return reactions, rows.Err()
}

func (s *server) editMessage(w http.ResponseWriter, r *http.Request, messageID, userID int64) {
	var body struct {
		Text string `json:"text"`
	}
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "Проверьте данные")
		return
	}
	text := strings.TrimSpace(body.Text)
	if text == "" || utf8.RuneCountInString(text) > 4000 {
		writeError(w, http.StatusBadRequest, "Сообщение должно содержать от 1 до 4000 символов")
		return
	}
	var item messageJSON
	var createdUnix int64
	err := s.db.QueryRow(`SELECT m.chat_id, m.sender_id, COALESCE(u.name, ''), CAST(UNIX_TIMESTAMP(m.created_at) AS SIGNED), m.reply_to_id, m.reply_sender_name, m.reply_text, m.reply_kind, m.forwarded_from_name, m.forwarded_from_id FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ? AND m.sender_id = ? AND m.kind = 'text'`, messageID, userID).Scan(&item.ChatID, &item.SenderID, &item.SenderName, &createdUnix, &item.ReplyToID, &item.ReplySender, &item.ReplyText, &item.ReplyKind, &item.ForwardedFrom, &item.ForwardedFromID)
	if errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить сообщение")
		return
	}
	item.ReplyText, err = s.decryptMessageText(item.ReplyText)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить сообщение")
		return
	}
	encryptedText, err := s.encryptMessageText(text)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить сообщение")
		return
	}
	result, err := s.db.Exec(`UPDATE messages SET text = ?, edited_at = CURRENT_TIMESTAMP(6) WHERE id = ? AND sender_id = ? AND kind = 'text'`, encryptedText, messageID, userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось изменить сообщение")
		return
	}
	if affected, affectedErr := result.RowsAffected(); affectedErr != nil || affected != 1 {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	}
	item.ID = messageID
	item.Text = text
	item.CreatedAt = timestampJSON(createdUnix)
	item.Kind = "text"
	item.Edited = true
	var memberCount int
	var otherLastRead int64
	if s.db.QueryRow(`SELECT COUNT(*), COALESCE(MIN(CASE WHEN user_id <> ? THEN last_read_message_id END), 0) FROM chat_members WHERE chat_id = ?`, userID, item.ChatID).Scan(&memberCount, &otherLastRead) == nil {
		item.Read = memberCount == 1 || item.ID <= otherLastRead
	}
	rows, err := s.db.Query(`SELECT user_id FROM chat_members WHERE chat_id = ?`, item.ChatID)
	if err == nil {
		var recipients []int64
		for rows.Next() {
			var recipientID int64
			if rows.Scan(&recipientID) == nil {
				recipients = append(recipients, recipientID)
			}
		}
		rows.Close()
		event, _ := json.Marshal(map[string]any{"type": "message_edited", "message": item})
		s.hub.broadcast(recipients, event)
	}
	item.Mine = true
	writeJSON(w, http.StatusOK, map[string]any{"message": item})
}

func (s *server) deleteMessage(w http.ResponseWriter, messageID, userID int64) {
	tx, err := s.db.Begin()
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось удалить сообщение")
		return
	}
	defer tx.Rollback()
	var chatID int64
	if err = tx.QueryRow(`SELECT m.chat_id FROM messages m WHERE m.sender_id = ? AND m.id = ? AND m.kind <> 'call' FOR UPDATE`, userID, messageID).Scan(&chatID); errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	} else if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось удалить сообщение")
		return
	}
	if _, err = tx.Exec(`DELETE FROM messages WHERE id = ? AND chat_id = ?`, messageID, chatID); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось удалить сообщение")
		return
	}
	if err = tx.Commit(); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось удалить сообщение")
		return
	}
	rows, err := s.db.Query(`SELECT user_id FROM chat_members WHERE chat_id = ?`, chatID)
	if err == nil {
		var recipients []int64
		for rows.Next() {
			var id int64
			if rows.Scan(&id) == nil {
				recipients = append(recipients, id)
			}
		}
		rows.Close()
		event, _ := json.Marshal(map[string]any{"type": "message_deleted", "chat_id": chatID, "message_id": messageID})
		s.hub.broadcast(recipients, event)
		for _, recipientID := range recipients {
			if recipientID != userID {
				s.enqueueNotification(recipientID, "", "", map[string]string{
					"type": "message_deleted", "chat_id": strconv.FormatInt(chatID, 10), "message_id": strconv.FormatInt(messageID, 10),
				})
			}
		}
	}
	writeJSON(w, http.StatusOK, map[string]bool{"deleted": true})
}

func (s *server) forwardMessage(w http.ResponseWriter, r *http.Request, messageID, userID int64) {
	var body struct {
		ChatID int64 `json:"chat_id"`
	}
	if err := decodeJSON(r, &body); err != nil || body.ChatID < 1 {
		writeError(w, http.StatusBadRequest, "Некорректный чат")
		return
	}
	senderName, err := s.userName(userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	tx, err := s.db.BeginTx(r.Context(), nil)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	defer tx.Rollback()
	var targetMember int
	if err = tx.QueryRowContext(r.Context(), `SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ? LOCK IN SHARE MODE`, body.ChatID, userID).Scan(&targetMember); errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusBadRequest, "Некорректный чат")
		return
	} else if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	var sourceChatID, sourceSenderID, mediaSize, mediaDuration, forwardedFromID int64
	var sourceSender, text, kind, mediaMime, mediaName, forwardedFrom string
	var mediaWidth, mediaHeight int
	err = tx.QueryRowContext(r.Context(), `SELECT m.chat_id, m.sender_id, COALESCE(u.name, ''), m.text, m.kind, COALESCE(m.media_mime, ''), COALESCE(m.media_name, ''), m.media_size, m.media_width, m.media_height, m.media_duration, m.forwarded_from_name, m.forwarded_from_id FROM messages m JOIN users u ON u.id = m.sender_id JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = ? WHERE m.id = ? LOCK IN SHARE MODE`, userID, messageID).Scan(&sourceChatID, &sourceSenderID, &sourceSender, &text, &kind, &mediaMime, &mediaName, &mediaSize, &mediaWidth, &mediaHeight, &mediaDuration, &forwardedFrom, &forwardedFromID)
	if errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	text, err = s.decryptMessageText(text)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	if kind == "call" {
		writeError(w, http.StatusBadRequest, "Событие звонка нельзя переслать")
		return
	}
	if forwardedFrom == "" {
		forwardedFrom = sourceSender
		forwardedFromID = sourceSenderID
	}
	encryptedText, err := s.encryptMessageText(text)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	result, err := tx.ExecContext(r.Context(), `INSERT INTO messages (chat_id, sender_id, text, kind, media_mime, media_name, media_size, media_width, media_height, media_duration, forwarded_from_name, forwarded_from_id, reply_text) VALUES (?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), ?, ?, ?, ?, ?, ?, '')`, body.ChatID, userID, encryptedText, kind, mediaMime, mediaName, mediaSize, mediaWidth, mediaHeight, mediaDuration, forwardedFrom, forwardedFromID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	forwardedID, err := result.LastInsertId()
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	if mediaSize > 0 {
		if _, err = tx.ExecContext(r.Context(), `INSERT INTO message_media_chunks (message_id, chunk_index, data) SELECT ?, chunk_index, data FROM message_media_chunks WHERE message_id = ?`, forwardedID, messageID); err != nil {
			writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
			return
		}
	}
	if err = tx.Commit(); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось переслать сообщение")
		return
	}
	createdUnix := time.Now().Unix()
	_ = s.updateRead(body.ChatID, userID, forwardedID)
	item := messageJSON{ID: forwardedID, ChatID: body.ChatID, SenderID: userID, SenderName: senderName, Text: text, CreatedAt: timestampJSON(createdUnix), Mine: true, Kind: kind, MediaMime: mediaMime, MediaName: mediaName, MediaSize: mediaSize, MediaWidth: mediaWidth, MediaHeight: mediaHeight, MediaDuration: mediaDuration, ForwardedFrom: forwardedFrom, ForwardedFromID: forwardedFromID}
	if kind == "image" || kind == "video" || kind == "video_note" || kind == "audio" || kind == "file" {
		item.MediaURL = "/media/" + strconv.FormatInt(forwardedID, 10)
	}
	s.deliverMessage(item, userID)
	writeJSON(w, http.StatusCreated, map[string]any{"message": item})
}

func (s *server) markMessageRead(w http.ResponseWriter, r *http.Request, chatID, userID int64) {
	var body struct {
		MessageID int64 `json:"message_id"`
	}
	if err := decodeJSON(r, &body); err != nil || body.MessageID < 1 {
		writeError(w, http.StatusBadRequest, "Некорректное сообщение")
		return
	}
	var exists int
	if err := s.db.QueryRow(`SELECT 1 FROM messages WHERE id = ? AND chat_id = ?`, body.MessageID, chatID).Scan(&exists); errors.Is(err, sql.ErrNoRows) {
		writeError(w, http.StatusNotFound, "Сообщение не найдено")
		return
	} else if err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отметить сообщение")
		return
	}
	if err := s.updateRead(chatID, userID, body.MessageID); err != nil {
		writeError(w, http.StatusInternalServerError, "Не удалось отметить сообщение")
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"read": true})
}

func (s *server) updateRead(chatID, userID, messageID int64) error {
	result, err := s.db.Exec(`UPDATE chat_members SET last_read_message_id = ? WHERE chat_id = ? AND user_id = ? AND last_read_message_id < ?`, messageID, chatID, userID, messageID)
	if err != nil {
		return err
	}
	affected, err := result.RowsAffected()
	if err != nil || affected == 0 {
		return err
	}
	event, err := json.Marshal(map[string]any{"type": "read", "chat_id": chatID, "reader_id": userID, "last_read_message_id": messageID})
	if err != nil {
		return err
	}
	rows, err := s.db.Query(`SELECT user_id FROM chat_members WHERE chat_id = ?`, chatID)
	if err != nil {
		return nil
	}
	defer rows.Close()
	recipients := make([]int64, 0, 2)
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			recipients = append(recipients, id)
		}
	}
	s.hub.broadcast(recipients, event)
	s.enqueueNotification(userID, "", "", map[string]string{
		"type": "read", "chat_id": strconv.FormatInt(chatID, 10), "message_id": strconv.FormatInt(messageID, 10),
	})
	return nil
}
