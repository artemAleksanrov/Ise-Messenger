package server

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestValidMessageReaction(t *testing.T) {
	for _, emoji := range []string{
		"👍", "❤️", "😂", "😮", "😢",
		"🔥", "👏", "🎉", "😍", "🤔",
		"👎", "😡", "🤯", "😭", "🙏",
		"👌", "💯", "🤣", "😊", "😎",
		"🤩", "😴", "🤢", "💩", "🥳",
	} {
		if !validMessageReaction(emoji) {
			t.Fatalf("expected %q to be allowed", emoji)
		}
	}
	for _, emoji := range []string{"", "🤡", "👍👍", "text"} {
		if validMessageReaction(emoji) {
			t.Fatalf("expected %q to be rejected", emoji)
		}
	}
}

func TestMessageReactionsJSONDistinguishesLoadedFromMissing(t *testing.T) {
	withoutReactions, err := json.Marshal(messageJSON{ID: 1})
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(withoutReactions), `"reactions"`) {
		t.Fatalf("unloaded reactions must be omitted: %s", withoutReactions)
	}

	empty := make([]messageReactionJSON, 0)
	withReactions, err := json.Marshal(messageJSON{ID: 1, Reactions: &empty})
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(withReactions), `"reactions":[]`) {
		t.Fatalf("loaded empty reactions must be an array: %s", withReactions)
	}
}
