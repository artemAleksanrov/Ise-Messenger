package server

import (
	"strings"
)

func (s *server) migrateMessageMetadata() error {
	var forwardedFromIDExists int
	if err := s.db.QueryRow(`SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'messages' AND column_name = 'forwarded_from_id'`).Scan(&forwardedFromIDExists); err != nil {
		return err
	}
	if forwardedFromIDExists == 0 {
		if _, err := s.db.Exec(`ALTER TABLE messages ADD COLUMN forwarded_from_id BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER forwarded_from_name`); err != nil {
			return err
		}
	}
	_, err := s.db.Exec(`CREATE TABLE IF NOT EXISTS message_reactions (
		message_id BIGINT UNSIGNED NOT NULL,
		user_id BIGINT UNSIGNED NOT NULL,
		emoji VARCHAR(16) NOT NULL,
		created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
		updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
		PRIMARY KEY (message_id, user_id),
		KEY message_reactions_user (user_id),
		KEY message_reactions_message_emoji (message_id, emoji),
		CONSTRAINT message_reactions_message_fk FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
		CONSTRAINT message_reactions_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`)
	return err
}

func (s *server) migrateStoredMessages() error {
	type storedMessage struct {
		id        int64
		text      string
		replyText string
	}
	for {
		rows, err := s.db.Query(`SELECT id, text, reply_text FROM messages WHERE (text <> '' AND text NOT LIKE 'enc:v1:%') OR (reply_text <> '' AND reply_text NOT LIKE 'enc:v1:%') ORDER BY id LIMIT 500`)
		if err != nil {
			return err
		}
		items := make([]storedMessage, 0, 500)
		for rows.Next() {
			var item storedMessage
			if err := rows.Scan(&item.id, &item.text, &item.replyText); err != nil {
				rows.Close()
				return err
			}
			items = append(items, item)
		}
		if err := rows.Err(); err != nil {
			rows.Close()
			return err
		}
		rows.Close()
		if len(items) == 0 {
			return nil
		}
		tx, err := s.db.Begin()
		if err != nil {
			return err
		}
		for _, item := range items {
			text := item.text
			if text != "" && !strings.HasPrefix(text, "enc:v1:") {
				text, err = s.encryptMessageText(text)
				if err != nil {
					tx.Rollback()
					return err
				}
			}
			replyText := item.replyText
			if replyText != "" && !strings.HasPrefix(replyText, "enc:v1:") {
				replyText, err = s.encryptMessageText(replyText)
				if err != nil {
					tx.Rollback()
					return err
				}
			}
			if _, err = tx.Exec(`UPDATE messages SET text = ?, reply_text = ? WHERE id = ?`, text, replyText, item.id); err != nil {
				tx.Rollback()
				return err
			}
		}
		if err = tx.Commit(); err != nil {
			return err
		}
	}
}
